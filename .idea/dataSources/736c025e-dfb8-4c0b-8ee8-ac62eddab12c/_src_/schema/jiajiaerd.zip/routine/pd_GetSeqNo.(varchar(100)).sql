CREATE PROCEDURE pd_GetSeqNo(IN Atablename VARCHAR(100), OUT AseqNo VARCHAR(100))
    top:BEGIN
  declare ASqlNo varchar(30);      # 临时编号
  declare Acurdate varchar(30);    # 当前日期
  declare AVFormat varchar(30);    # 格式
  declare APreFix varchar(30);     # 前缀
  declare Asuffix varchar(30);     # 后缀
  declare Aincre int;              # 递增大小
  declare AstartNo int;            # 起始值
  declare Acur int;                # 当前编号
  declare Acurdoc varchar(30);     # 当前日期时间
  declare Astartnew char(1);
  declare Ai int;
  declare AdateFormat varchar(30);
  declare Apart varchar(30);
  declare Aj int;
  declare Acurstr varchar(30);
  declare ACut_len int;
	declare Asguid varchar(50);

	select sguid  into Asguid
	from cs_sequence 
  where UPPER( scode )= UPPER( Atablename ) ;

if(Asguid is null) then
	INSERT INTO cs_sequence(sguid, scode, sobjectname, sfromat, iincrement, istartno, icurrentno, sprefix,ssuffix, sseqlength, dcurrentdate, biscycle, sremark, bisreset) VALUES (REPLACE(UUID(), '-', ''), Atablename,Atablename , '000000', 1, 1, 1, '', '', 1, '', 0, '', 1);


	select sguid  into Asguid
	from cs_sequence 
  where UPPER( scode )= UPPER( Atablename ) ;
	end if;
	
	
  select UPPER(IfNull(sfromat,'')),IfNull(sprefix,''),IfNull(ssuffix,''),
         IfNull(iincrement,1),IfNull(istartno,0),IfNull(icurrentno,0),
         IfNull(dcurrentdate,''),IfNull(biscycle,0)
  into   AVFormat,APreFix,Asuffix,Aincre,AstartNo,Acur,Acurdoc,Astartnew
  from cs_sequence   
  where sguid = Asguid for update;

  #  select  AVFormat,APreFix,Asuffix,Aincre,AstartNo,Acur,Acurdoc,Astartnew;
  if ( AstartNo is null ) or ( AstartNo<2 ) then
    set AstartNo := 0;
  end if;

  # 分成时间与数字两部分
  set Ai := INSTR( AVFormat,'0');
  set AdateFormat := SUBSTR( AVFormat, 1 , (Ai-1) );
  set AVFormat := SUBSTR( AVFormat,Ai,(LENGTH( AVFormat) - Ai+1 ) );
  # select ai,  AdateFormat, AVFormat ;
  # 对时间部分处理
  if LENGTH( AdateFormat ) > 0 then
     set  Ai := INSTR( AdateFormat , '-' );
     if Ai > 0 then  # 具有-
        set ASqlNo := '-';
        set AdateFormat := SUBSTR( AdateFormat, 1 , (Ai-1));
     end if;
     #  select "-:" ,Ai, ASqlNo, AdateFormat;
     set Ai := INSTR(AdateFormat , 'DD' );
     if Ai > 0 then  # 具有天
        set Apart := CAST(DAYOFMONTH(current_date) AS CHAR(10));
      #   select  Apart;
        set Aj := 2-LENGTH( Apart );
        while Aj>0
        do
          set Apart :=CONCAT('0', Apart);
          set Aj :=Aj-1;
        end while;
        set ASqlNo := CONCAT(Apart,ifnull(ASqlNo,''));
        set Acurdate := Apart;
        set AdateFormat := SUBSTR(AdateFormat,1 , (Ai-1));
     end if;
     # select '天:' ,Ai, ASqlNo, AdateFormat  ;
     set Ai := INSTR(AdateFormat,'MM');
     if Ai>0 then  # 具有月
       set Apart := CAST(MONTH(current_date) AS CHAR(10));
       set Aj := 2 - LENGTH(Apart);
       while Aj>0
       do
         set Apart := CONCAT('0',Apart);
         set Aj := Aj-1;
       end while;
       if ASqlNo is null then
         set ASqlNo := Apart;
       else
         set ASqlNo := CONCAT(Apart , ASqlNo);
       end if;

       if Acurdate is null then
         set Acurdate := Apart;
       else
         set Acurdate := CONCAT(Apart, Acurdate);
       end if;
       set AdateFormat := SUBSTR(AdateFormat,1,(Ai-1));
     end if;
       #  select '月:' ,Ai, ASqlNo, AdateFormat;
     if LENGTH(AdateFormat)>0 then  # 具有年
       set Apart := CAST(YEAR(current_date) AS CHAR(10));
       set Aj := 4 -LENGTH(Apart);
       while Aj>0
       do
         set Apart := '0' || Apart;
         set Aj := Aj-1;
       end while;
       if ASqlNo is null then
         set ASqlNo := SUBSTR(Apart,LENGTH(Apart)-LENGTH(AdateFormat)+1,LENGTH(AdateFormat));
       else
         set ASqlNo := CONCAT(SUBSTR(Apart,LENGTH(Apart)-LENGTH(AdateFormat)+1,LENGTH(AdateFormat)), ASqlNo);
       end if;
       # select    Acurdate;
       if Acurdate is null then
         set Acurdate :=Apart;
       else
         set Acurdate :=CONCAT(Apart , Acurdate);
       end if;
       select  Acurdate;
     end if;
     # select '年:' ,Ai, ASqlNo, AdateFormat;
   end if;

   # 判断是否要归零
   if (Astartnew=1) then
     if ( Acurdoc is null  ) or (Acurdate<>Acurdoc) then
       set Acur := AstartNo;
     end if;
   end if;

  # 添加前缀
  set ASqlNo := CONCAT(APreFix , ifnull(ASqlNo,''));
   # select  ASqlNo, APreFix, ASqlNo ;
  # 对数字部分处理
   if LENGTH(AVFormat)>0 THEN
       if Aincre=0 then
         set Aincre :=1;
       end if;

       if AstartNo > Acur then
         set Acur := AstartNo;
       end if;

       set Acur := Acur + Aincre;
       # 更改currentNext
       update cs_sequence set icurrentno=Acur,dcurrentdate=Acurdate where sguid=Asguid;

       if row_count() <=0 then
           set ASeqNo := '-1';
           leave top;
       end if;


       set Acurstr := Acur;
       set ACut_len :=LENGTH( AVFormat ) - LENGTH( Acurstr );

       set AVFormat := SUBSTR(AVFormat,1,case when ACut_len<0 then 0 else ACut_len end);
       set ASqlNo := CONCAT(ASqlNo , AVFormat , Acurstr , Asuffix);
   end IF;

   set AseqNo := ASqlNo;
 #  commit;

END;
