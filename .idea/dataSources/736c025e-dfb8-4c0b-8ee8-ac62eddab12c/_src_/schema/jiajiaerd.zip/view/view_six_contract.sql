CREATE VIEW view_six_contract AS
  SELECT
    `_temp`.`sname`                                                              AS `sname`,
    group_concat(`_temp`.`svalue` ORDER BY `_temp`.`dadddate` ASC SEPARATOR ',') AS `svalue`
  FROM (SELECT
          `xm`.`smaincontractname`  AS `sname`,
          `xm`.`fmaincontractprice` AS `svalue`,
          `xm`.`dadddate`           AS `dadddate`
        FROM (`jiajiaerd`.`xm_contractmsg` `xm` LEFT JOIN `jiajiaerd`.`cs_parameter` `cs`
            ON ((`xm`.`smaincontractname` = `cs`.`sparametervalue`)))
        WHERE ((`cs`.`sparametervalue` IS NOT NULL) AND (`cs`.`iparatype` = 1))
        ORDER BY `xm`.`dadddate` DESC
        LIMIT 0, 4) `_temp`
  UNION ALL SELECT
              `_temp`.`sname`                                                              AS `sname`,
              group_concat(`_temp`.`svalue` ORDER BY `_temp`.`dadddate` ASC SEPARATOR ',') AS `svalue`
            FROM (SELECT
                    `xm`.`snextcontractname`  AS `sname`,
                    `xm`.`fnextcontractprice` AS `svalue`,
                    `xm`.`dadddate`           AS `dadddate`
                  FROM (`jiajiaerd`.`xm_contractmsg` `xm` LEFT JOIN `jiajiaerd`.`cs_parameter` `cs`
                      ON ((`xm`.`snextcontractname` = `cs`.`sparametervalue`)))
                  WHERE ((`cs`.`sparametervalue` IS NOT NULL) AND (`cs`.`iparatype` = 2))
                  ORDER BY `xm`.`dadddate` DESC
                  LIMIT 0, 4) `_temp`
  UNION ALL SELECT
              `_temp`.`sname`                                                              AS `sname`,
              group_concat(`_temp`.`svalue` ORDER BY `_temp`.`dadddate` ASC SEPARATOR ',') AS `svalue`
            FROM (SELECT
                    `xm`.`snextnextcontractname`  AS `sname`,
                    `xm`.`fnextnextcontractprice` AS `svalue`,
                    `xm`.`dadddate`               AS `dadddate`
                  FROM (`jiajiaerd`.`xm_contractmsg` `xm` LEFT JOIN `jiajiaerd`.`cs_parameter` `cs`
                      ON ((`xm`.`snextnextcontractname` = `cs`.`sparametervalue`)))
                  WHERE ((`cs`.`sparametervalue` IS NOT NULL) AND (`cs`.`iparatype` = 3))
                  ORDER BY `xm`.`dadddate` DESC
                  LIMIT 0, 4) `_temp`;
